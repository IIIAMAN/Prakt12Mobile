package com.example.pr12mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BotActivity extends AppCompatActivity {

    private boolean ktohodit = true;
    private Button[][] buttons = new Button[3][3];
    private boolean gameEnded = false;
    private TextView statusTextView;
    private GridLayout gridLayout;
    private Button resetButton;
    private SharedPreferences sharedPreferences;
    private int playerwin = 0;
    private int botWins = 0;
    private int nichya = 0;
    private TextView TextPlay1Win;
    private TextView TextPlay2Win;
    private TextView NichyaTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bot_game);

        statusTextView = findViewById(R.id.statusTextView);
        gridLayout = findViewById(R.id.gridLayout);
        resetButton = findViewById(R.id.resetButton);
        TextPlay1Win = findViewById(R.id.player1WinsTextView);
        TextPlay2Win = findViewById(R.id.player2WinsTextView);
        NichyaTextView = findViewById(R.id.drawsTextView);

        sharedPreferences = getSharedPreferences("GameStats", MODE_PRIVATE);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int buttonId = getResources().getIdentifier("button" + (i * 3 + j + 1), "id", getPackageName());
                buttons[i][j] = findViewById(buttonId);
                buttons[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onGridButtonClick((Button) v);
                    }
                });
            }
        }

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });

        loadGameStats();
        updateGameStatsText();
        resetGame();
    }

    private void onGridButtonClick(Button button) {
        if (gameEnded || !ktohodit) return;

        if (button.getText().toString().isEmpty()) {
            button.setText("X");

            if (checkForWin()) {
                String winner = "Игрок 1 (X)";
                displayWinner(winner);
                playerwin++;
            } else if (Risuem()) {
                displayNichya();
                nichya++;
            } else {
                ktohodit = false;
                updateStatusText();

                BotHodit();
            }

            updateGameStatsText();
            saveGameStats();
        }
    }

    private void BotHodit() {
        List<Button> emptyCells = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().toString().isEmpty()) {
                    emptyCells.add(buttons[i][j]);
                }
            }
        }

        if (!emptyCells.isEmpty()) {
            Random random = new Random();
            int randomIndex = random.nextInt(emptyCells.size());
            Button randomCell = emptyCells.get(randomIndex);
            randomCell.setText("O");
        }

        if (checkForWin()) {
            String winner = "Бот (O)";
            displayWinner(winner);
            botWins++;
        } else if (Risuem()) {
            displayNichya();
            nichya++;
        }else{
            ktohodit = true;
            updateStatusText();
            updateGameStatsText();
            saveGameStats();
        }
    }

    private boolean checkForWin() {
        for (int i = 0; i < 3; i++) {
            if (buttons[i][0].getText().equals(buttons[i][1].getText()) &&
                    buttons[i][1].getText().equals(buttons[i][2].getText()) && !buttons[i][0].getText().toString().isEmpty()) {
                return true;
            }
            if (buttons[0][i].getText().equals(buttons[1][i].getText()) &&
                    buttons[1][i].getText().equals(buttons[2][i].getText()) && !buttons[0][i].getText().toString().isEmpty()) {
                return true;
            }
        }

        if (buttons[0][0].getText().equals(buttons[1][1].getText()) &&
                buttons[1][1].getText().equals(buttons[2][2].getText()) && !buttons[0][0].getText().toString().isEmpty()) {
            return true;
        }
        if (buttons[0][2].getText().equals(buttons[1][1].getText()) &&
                buttons[1][1].getText().equals(buttons[2][0].getText()) && !buttons[0][2].getText().toString().isEmpty()) {
            return true;
        }

        return false;
    }

    private boolean Risuem() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().toString().isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }

    private void displayWinner(String winner) {
        gameEnded = true;
        statusTextView.setText("Победил " + winner);
    }

    private void displayNichya() {
        gameEnded = true;
        statusTextView.setText("Ничья!");
    }

    private void updateStatusText() {
        String currentPlayer = ktohodit ? "Игрок 1 (X)" : "Бот (O)";
        statusTextView.setText("Ход " + currentPlayer);
    }

    private void resetGame() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }
        ktohodit = true;
        gameEnded = false;
        statusTextView.setText("Ход игрока 1 (X)");
    }

    private void saveGameStats() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("Player11Wins", playerwin);
        editor.putInt("BotWins", botWins);
        editor.putInt("Draws1", nichya);
        editor.apply();
    }

    private void loadGameStats() {
        playerwin = sharedPreferences.getInt("Player11Wins", 0);
        botWins = sharedPreferences.getInt("BotWins", 0);
        nichya = sharedPreferences.getInt("Draws1", 0);
    }

    private void updateGameStatsText() {
        TextPlay1Win.setText("Победы игрока 1: " + playerwin);
        TextPlay2Win.setText("Победы бота: " + botWins);
        NichyaTextView.setText("Ничьи: " + nichya);
    }
}