package com.example.pr12mobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SharedPreferences settings;
    SharedPreferences.Editor editor;
    ImageButton switchButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Button playWithBotButton = findViewById(R.id.button2);
        Button playWithPlayerButton = findViewById(R.id.button);

        playWithBotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, BotActivity.class);
                startActivity(intent);
            }
        });

        playWithPlayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
                startActivity(intent);
            }
        });

        settings = getSharedPreferences("SETTINGS", MODE_PRIVATE);

        if (settings.contains("MODE_NIGHT_ON")){
            getCurrentTheme();
        }else{
            editor = settings.edit();
            editor.putBoolean("MODE_NIGHT_ON", false);
            editor.apply();
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "Hello, new user!!!", Toast.LENGTH_SHORT).show();
        }


        switchButton = findViewById(R.id.switch_button);

        if (settings.getBoolean("MODE_NIGHT_ON", false)){
            switchButton.setImageResource(R.drawable.ic_day);
        }else{
            switchButton.setImageResource(R.drawable.ic_night1);
        }

        switchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                editor = settings.edit();
                if (settings.getBoolean("MODE_NIGHT_ON", false)){
                    editor.putBoolean("MODE_NIGHT_ON", false);
                }else{
                    editor.putBoolean("MODE_NIGHT_ON", true);
                }

                editor.apply();

                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });
    }

    private void getCurrentTheme(){
        if (settings.getBoolean("MODE_NIGHT_ON", false)){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }else{
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }
}