package com.example.pr12mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

public class PlayerActivity extends AppCompatActivity {

    private boolean viborIgrok = true;
    private Button[][] buttons = new Button[3][3];
    private boolean endgame = false;
    private TextView statustext;
    private GridLayout gridLayout;
    private Button resetButton;
    private SharedPreferences sharedPreferences;
    private int player1Wins = 0;
    private int player2Wins = 0;
    private TextView player1WinsTextView;
    private TextView player2WinsTextView;

    private TextView nichyaText;

    private int nichya = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_game);

        statustext = findViewById(R.id.statusTextView);
        gridLayout = findViewById(R.id.gridLayout);
        resetButton = findViewById(R.id.resetButton);
        player1WinsTextView = findViewById(R.id.player1WinsTextView);
        player2WinsTextView = findViewById(R.id.player2WinsTextView);
        nichyaText = findViewById(R.id.drawsTextView);

        sharedPreferences = getSharedPreferences("GameStats", MODE_PRIVATE);


        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int buttonId = getResources().getIdentifier("button" + (i * 3 + j + 1), "id", getPackageName());
                buttons[i][j] = findViewById(buttonId);
                buttons[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onGridButtonClick((Button) v);
                    }
                });
            }
        }

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });

        loadGameStats();
        updateGameStatsText();
        resetGame();
    }

    private void onGridButtonClick(Button button) {
        if (endgame) return;

        if (button.getText().toString().isEmpty()) {
            if (viborIgrok) {
                button.setText("X");
            } else {
                button.setText("O");
            }

            if (ktowin()) {
                String winner = viborIgrok ? "Игрок 1 (X)" : "Игрок 2 (O)";
                displayWinner(winner);
            } else if (vivodinf()) {
                DisplayNichya();
            } else {
                viborIgrok = !viborIgrok;
                updateinfText();
            }
        }
    }

    private boolean ktowin() {
        for (int i = 0; i < 3; i++) {
            if (buttons[i][0].getText().equals(buttons[i][1].getText()) &&
                    buttons[i][1].getText().equals(buttons[i][2].getText()) && !buttons[i][0].getText().toString().isEmpty()) {
                return true;
            }
            if (buttons[0][i].getText().equals(buttons[1][i].getText()) &&
                    buttons[1][i].getText().equals(buttons[2][i].getText()) && !buttons[0][i].getText().toString().isEmpty()) {
                return true;
            }
        }

        if (buttons[0][0].getText().equals(buttons[1][1].getText()) &&
                buttons[1][1].getText().equals(buttons[2][2].getText()) && !buttons[0][0].getText().toString().isEmpty()) {
            return true;
        }
        if (buttons[0][2].getText().equals(buttons[1][1].getText()) &&
                buttons[1][1].getText().equals(buttons[2][0].getText()) && !buttons[0][2].getText().toString().isEmpty()) {
            return true;
        }

        return false;
    }

    private boolean vivodinf() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().toString().isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }

    private void displayWinner(String winner) {
        endgame = true;
        statustext.setText("Победил " + winner);

        if (winner.equals("Игрок 1 (X)")) {
            player1Wins++;
        } else {
            player2Wins++;
        }
        saveGameStats();
        updateGameStatsText();
    }

    private void DisplayNichya() {
        endgame = true;
        statustext.setText("Ничья!");
        nichya++;
        saveGameStats();
        updateGameStatsText();
    }

    private void updateinfText() {
        String currentPlayer = viborIgrok ? "Игрок 1 (X)" : "Игрок 2 (O)";
        statustext.setText("Ход " + currentPlayer);
    }

    private void resetGame() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }
        viborIgrok = true;
        endgame = false;
        statustext.setText("Ход игрока 1 (X)");
    }

    private void saveGameStats() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("Player1Wins", player1Wins);
        editor.putInt("Player2Wins", player2Wins);
        editor.putInt("Draws", nichya);
        editor.apply();
    }

    private void loadGameStats() {
        player1Wins = sharedPreferences.getInt("Player1Wins", 0);
        player2Wins = sharedPreferences.getInt("Player2Wins", 0);
        nichya = sharedPreferences.getInt("Draws", 0);
    }

    private void updateGameStatsText() {
        player1WinsTextView.setText("Победы игрока 1: " + player1Wins);
        player2WinsTextView.setText("Победы игрока 2: " + player2Wins);
        nichyaText.setText("Ничьи: " + nichya);
    }
}